# v19 正模型 MATLAB 包（fwd_mf / fwd_mf_impl）

## 这是什么

300 轮冷启动、seed 7 的 v19 A 正模型，MATLAB Function 版，供 PMPC
Simulink 用。不是 30 轮 Stage-1 的 A 臂。

- 架构：GRU 2×16、MLP 48、G 24，共 21041 参数
- 权重来源：`training_outputs/v19_capacity_four_20261028/training_delivery/sessions/A/final.pth`
- 权重 SHA256：`3a407a77e8f0b9167282fdbfc77923dac23fcd0430fa498432e36e31f97423c7`
- τ（CurrentLag）：12.5297 ms
- 归一化：x_ref = 281.06649017333984，x_scale = 62.03949737548828，
  f_scale = 7662.43017578125，v_scale = 1000，a_scale = 50000，
  i_scale = 1.6，t_ref = 40，t_scale = 40
- 验证：Python 复写 MATLAB 算法，与 PyTorch A 模型在 SH 10mm 1.66Hz 0.4A
  数据上连跑 500 步，无 warmup 和有 warmup 两种情况最大差约 0.0002 N。

## 包里有什么

- `fwd_mf.m`：MATLAB Function 块里贴的 3 行 wrapper
- `fwd_mf_impl.m`：算法实体，放在 Simulink 工作目录
- `fwd_weights.mat`：权重与归一化参数，放在同一工作目录
- 本 README

注意：`fwd_weights.mat` 是二进制 MAT 文件，用编辑器打开看到乱码是正常的，
不要按文本打开。用 MATLAB 命令 `load('fwd_weights.mat')` 检查即可。

## 替换步骤

1. 把本包三个文件（`fwd_mf.m`、`fwd_mf_impl.m`、`fwd_weights.mat`）
   放进 Simulink 工作目录。
2. 4 个 MATLAB Function 块里的内容换成 `fwd_mf.m` 的 3 行。
3. 跑之前先清各角 persistent 状态：`clear fwd_mf_impl`。
4. 如果之前用的是 `v19A_weights.mat`，删掉它，本包 impl 读的是
   `fwd_weights.mat`，只留旧名会报错。

## 接口（与 v17_fwd_mf 相同）

输入（全部标量）：
- `t`：仿真时间 [s]
- `Temp_C`：油温 [degC]，如 30
- `cmpD`：减振器位移 [mm]，CarSim 符号（压缩 +）
- `cmpRD`：减振器速度 [mm/s]，CarSim 符号
- `I_cmd`：电流指令 [A]，内部限幅 [0, 1.6]
- `cid`：角 id，1=L1、2=L2、3=R1、4=R2（每块固定，接线前按真实顺序核对）

输出：
- `F`：减振器力 [N]，CarSim 符号（压缩 +）

## 模型口径（与 v17 的区别）

- observer 严格过去：运动/温度取当前拍，电流只取上一拍已施加电流；
  dI 由已施加电流历史重算，当前待求电流不泄漏进 observer。
- 电流滞后是因果 EMA（CurrentLag），不是 v17 的 FIR 缓冲。
- 加速度与 v17 impl 相同：速度经 20 ms 低通求导得到，不是台架实测
  加速度通道。
- 首步有 200 步预滚（与 v17 impl 同理），不想要 raw 零状态首步就删掉
  impl 里标了 warmup 的那一段。
- 力公式：F = c·v·G_c(q) + Σ s_k·tanh(v/σ_k)·G_s(q) + b，
  q = 1 − 有效电流，σ = [0.5, 1, 2, 4, 8]，输出最后乘 f_scale 并取
  rig → CarSim 符号（取负）。

## 提醒

这次只换了正模型，控制器那边的逆模型还是 v17 的。闭环时是 v17 逆解
去追这个 A plant，两模型差会直接进闭环误差。换逆模型时，F_des 的
产生口径必须与逆解所逆的那个正模型一致，否则 round-trip 对不上。

## 2026-10-29 修正

权重已改为 double。PyTorch 导出的是 float32，MATLAB 里是 single，
Simulink codegen 不允许把 single 结果赋回 double 的状态变量，
会在 fwd_mf_impl.m 第 104 行报 single/double 类型错误。
如手头还是旧 single 版，用 MATLAB 转一次即可（见聊天记录里的转换命令），
数值不变（float32 转 double 是精确转换）。
