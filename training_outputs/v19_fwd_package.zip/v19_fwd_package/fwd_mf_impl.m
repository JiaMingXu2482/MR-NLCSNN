function F = fwd_mf_impl(t, Temp_C, cmpD, cmpRD, I_cmd, cid)
%FWD_MF_IMPL  v19 A forward damper model, ONE corner, for MATLAB Function block.
%   %#codegen compatible. Build MEX per block for speed.
%
%   F = fwd_mf_impl(t, Temp_C, cmpD, cmpRD, I_cmd, cid)
%
%   This is the 300-epoch, cold-start, seed-7 A arm from
%   training_outputs/v19_capacity_four_20261028 (branch
%   train/nlcsnn-v3-5pct), NOT the 30-epoch Stage-1 A arms.
%   Architecture: GRU 2x16, MLP 48, G 24, 21041 parameters.
%   Observer is strictly past: motion/temperature at this sample,
%   current only through the previous applied sample; dI is recomputed
%   from committed current history, never from the current command.
%
%   Drop a MATLAB Function block per corner (4 blocks). Wire 6 scalar
%   inputs / 1 scalar output. For speed: right-click -> C/C++ Code ->
%   Build This Subsystem. The cid selects the state slot so corners
%   never cross-contaminate even in interpreted mode.
%
%   Inputs (all scalars, same interface and signs as v17_fwd_mf):
%     t       simulation time [s]
%     Temp_C  oil temperature [degC] (e.g. 30)
%     cmpD    damper displacement [mm], CarSim sign (compression +)
%     cmpRD   damper velocity [mm/s], CarSim sign
%     I_cmd   current command [A], clamped to [0,1.6] inside
%     cid     corner id: 1=L1, 2=L2, 3=R1, 4=R2 (constant per block)
%
%   Output:
%     F       damper force [N], CarSim sign (compression +)
%
%   Reset between runs: clear fwd_mf_impl   (resets all 4 corners)
%
%   Files required in the same directory as this file:
%     fwd_weights.mat  (exported from sessions/A/final.pth)

%#codegen

persistent net st_h st_prev st_preveff st_prevprev t_prevs v_prevs a_filts

NC = 4;
TAU_ACCEL = 0.02;

if isempty(net)
    net = fwd_net_init_cg();
    st_h = zeros(2, 16, NC);
    st_prev = zeros(1, NC);
    st_preveff = zeros(1, NC);
    st_prevprev = zeros(1, NC);
    t_prevs = NaN(1, NC);
    v_prevs = zeros(1, NC);
    a_filts = zeros(1, NC);
end

cid = max(1, min(NC, round(cid)));
I_cmd = min(max(I_cmd, 0), 1.6);
I_norm = I_cmd / 1.6;

t_prev = t_prevs(cid);
first_step = isnan(t_prev);
if first_step
    dt = 0.001;
else
    dt = t - t_prev;
    if ~(dt > 0) || ~isfinite(dt)
        dt = 0.001;
    end
end
t_prevs(cid) = t;

n = net.norm;
x_rig = n.x_ref - cmpD;
v_rig = -cmpRD;
if first_step
    a_rig = 0;
else
    a_raw = (v_rig - v_prevs(cid)) / dt;
    if ~isfinite(a_raw), a_raw = 0; end
    alpha_a = 1 - exp(-dt / TAU_ACCEL);
    a_rig = (1 - alpha_a) * a_filts(cid) + alpha_a * a_raw;
    if ~isfinite(a_rig), a_rig = 0; end
end
v_prevs(cid) = v_rig;
a_filts(cid) = a_rig;

% Normalised motion sample (rig sign). This sample is held constant
% across the 1 ms substeps below; only the model state advances.
x_norm = (x_rig - n.x_ref) / n.x_scale;
v_norm = v_rig / n.v_scale;
a_norm = a_rig / n.a_scale;
T_norm = (Temp_C - n.t_ref) / n.t_scale;

h = st_h(:, :, cid);
prev_I = st_prev(cid);
prev_eff = st_preveff(cid);
prevprev_I = st_prevprev(cid);

% First-step warmup, same intent as v17_fwd_mf_impl: pre-roll 200 steps
% with the first sample so the GRU state and effective current settle.
% Training excluded the first 1000 samples of every file, so the zero
% state is out of distribution and the force spikes at t=0 without this.
% Delete this block if you want the raw zero-state first step instead.
if first_step
    for kw = 1:200
        [~, h, prev_I, prev_eff, prevprev_I] = ...
            fwd_step(net, x_norm, v_norm, a_norm, T_norm, I_norm, ...
                      h, prev_I, prev_eff, prevprev_I);
    end
end

% ---- forward step, 1 ms substeps (matches the 1 ms training sample) ----
n_sub = max(1, round(dt / 0.001));
Fn = 0;
for k = 1:n_sub
    [Fn, h, prev_I, prev_eff, prevprev_I] = ...
        fwd_step(net, x_norm, v_norm, a_norm, T_norm, I_norm, ...
                  h, prev_I, prev_eff, prevprev_I);
end

st_h(:, :, cid) = h;
st_prev(cid) = prev_I;
st_preveff(cid) = prev_eff;
st_prevprev(cid) = prevprev_I;

F_model = Fn * n.f_scale;
F = -F_model;   % rig -> CarSim sign
end


function [Fn, h_new, prev_I_new, prev_eff_new, prevprev_new] = ...
    fwd_step(net, x_norm, v_norm, a_norm, T_norm, I_norm, ...
              h, prev_I, prev_eff, prevprev_I)
%#codegen
% One 1 ms model step. The observer sees the PREVIOUS applied current
% and the recomputed strictly-past dI; the current command enters only
% through the CurrentLag step in the force map, then commits as state.
di = prev_I - prevprev_I;
u_obs = [x_norm; v_norm; a_norm; prev_I; di; T_norm];
nfl = build_nfl_v19(u_obs);
h_new = gru_step_v19(net, nfl, h);
h2 = h_new(2, :)';
v_out = v_norm * net.cfg.v_out_scale;
feat = [h2; nfl; abs(v_out)];
c_slow = mlp3(net.c_head_W1, net.c_head_b1, net.c_head_W2, ...
              net.c_head_b2, net.c_head_W3, net.c_head_b3, feat);
s_slow = mlp3(net.s_head_W1, net.s_head_b1, net.s_head_W2, ...
              net.s_head_b2, net.s_head_W3, net.s_head_b3, feat);
b = mlp3(net.b_head_W1, net.b_head_b1, net.b_head_W2, ...
         net.b_head_b2, net.b_head_W3, net.b_head_b3, [h2; nfl]);
fast_in = [1 - prev_I; 1 - prev_eff];
c_fast = mlp2(net.c_fast_W1, net.c_fast_b1, net.c_fast_W2, net.c_fast_b2, fast_in);
s_fast = mlp2(net.s_fast_W1, net.s_fast_b1, net.s_fast_W2, net.s_fast_b2, fast_in);
c = softplus_stable(c_slow + c_fast) + 1e-6 + 2e-3;
sj = softplus_stable(s_slow + s_fast) + 1e-6 + 5e-3 / 5;
phi = tanh(v_out ./ net.sigmas);
% CurrentLag: exact causal EMA, 1 ms step, tau from the checkpoint.
alpha_lag = 1 - exp(-1 / net.cfg.tau_ms);
eff = prev_eff + alpha_lag * (I_norm - prev_eff);
q = 1 - eff;
Gc = monoG(net.G_c_W1, net.G_c_b1, net.G_c_W2, net.G_c_b2, ...
           net.G_c_W3, net.G_c_b3, net.G_c_f0, net.G_c_gref, net.k_skip, q);
Gs = monoG(net.G_s_W1, net.G_s_b1, net.G_s_W2, net.G_s_b2, ...
           net.G_s_W3, net.G_s_b3, net.G_s_f0, net.G_s_gref, net.k_skip, q);
Fn = c * v_out * Gc + (sj' * phi) * Gs + b;
prev_I_new = I_norm;
prev_eff_new = eff;
prevprev_new = prev_I;
end


function net = fwd_net_init_cg()
%#codegen
S = coder.load('fwd_weights.mat');
net = struct();
net.W_ir0=S.W_ir0; net.W_hr0=S.W_hr0; net.b_ir0=S.b_ir0; net.b_hr0=S.b_hr0;
net.W_iz0=S.W_iz0; net.W_hz0=S.W_hz0; net.b_iz0=S.b_iz0; net.b_hz0=S.b_hz0;
net.W_in0=S.W_in0; net.W_hn0=S.W_hn0; net.b_in0=S.b_in0; net.b_hn0=S.b_hn0;
net.W_ir1=S.W_ir1; net.W_hr1=S.W_hr1; net.b_ir1=S.b_ir1; net.b_hr1=S.b_hr1;
net.W_iz1=S.W_iz1; net.W_hz1=S.W_hz1; net.b_iz1=S.b_iz1; net.b_hz1=S.b_hz1;
net.W_in1=S.W_in1; net.W_hn1=S.W_hn1; net.b_in1=S.b_in1; net.b_hn1=S.b_hn1;
net.c_head_W1=S.c_head_W1; net.c_head_b1=S.c_head_b1;
net.c_head_W2=S.c_head_W2; net.c_head_b2=S.c_head_b2;
net.c_head_W3=S.c_head_W3; net.c_head_b3=S.c_head_b3;
net.s_head_W1=S.s_head_W1; net.s_head_b1=S.s_head_b1;
net.s_head_W2=S.s_head_W2; net.s_head_b2=S.s_head_b2;
net.s_head_W3=S.s_head_W3; net.s_head_b3=S.s_head_b3;
net.b_head_W1=S.b_head_W1; net.b_head_b1=S.b_head_b1;
net.b_head_W2=S.b_head_W2; net.b_head_b2=S.b_head_b2;
net.b_head_W3=S.b_head_W3; net.b_head_b3=S.b_head_b3;
net.c_fast_W1=S.c_fast_W1; net.c_fast_b1=S.c_fast_b1;
net.c_fast_W2=S.c_fast_W2; net.c_fast_b2=S.c_fast_b2;
net.s_fast_W1=S.s_fast_W1; net.s_fast_b1=S.s_fast_b1;
net.s_fast_W2=S.s_fast_W2; net.s_fast_b2=S.s_fast_b2;
% NOTE: compute G f0/gref from LOCAL copies; do not pass `net` to a
% function before all its fields are assigned (codegen forbids adding
% fields after the struct has been read/used).
k_skip = S.cfg.g_k_skip;
Gc_W1=softplus_stable(S.G_c_Wr1); Gc_b1=S.G_c_b1;
Gc_W2=softplus_stable(S.G_c_Wr2); Gc_b2=S.G_c_b2;
Gc_W3=softplus_stable(S.G_c_Wr3); Gc_b3=S.G_c_b3;
Gs_W1=softplus_stable(S.G_s_Wr1); Gs_b1=S.G_s_b1;
Gs_W2=softplus_stable(S.G_s_Wr2); Gs_b2=S.G_s_b2;
Gs_W3=softplus_stable(S.G_s_Wr3); Gs_b3=S.G_s_b3;
Gc_f0 = monoG_raw_w(Gc_W1,Gc_b1,Gc_W2,Gc_b2,Gc_W3,Gc_b3,0);
Gc_gref = (monoG_raw_w(Gc_W1,Gc_b1,Gc_W2,Gc_b2,Gc_W3,Gc_b3,1)-Gc_f0) ...
          + k_skip * 1;
Gs_f0 = monoG_raw_w(Gs_W1,Gs_b1,Gs_W2,Gs_b2,Gs_W3,Gs_b3,0);
Gs_gref = (monoG_raw_w(Gs_W1,Gs_b1,Gs_W2,Gs_b2,Gs_W3,Gs_b3,1)-Gs_f0) ...
          + k_skip * 1;
net.G_c_W1=Gc_W1; net.G_c_b1=Gc_b1;
net.G_c_W2=Gc_W2; net.G_c_b2=Gc_b2;
net.G_c_W3=Gc_W3; net.G_c_b3=Gc_b3;
net.G_s_W1=Gs_W1; net.G_s_b1=Gs_b1;
net.G_s_W2=Gs_W2; net.G_s_b2=Gs_b2;
net.G_s_W3=Gs_W3; net.G_s_b3=Gs_b3;
net.k_skip=k_skip;
net.G_c_f0=Gc_f0; net.G_c_gref=Gc_gref;
net.G_s_f0=Gs_f0; net.G_s_gref=Gs_gref;
net.sigmas = S.cfg.sigmas;
net.norm   = S.norm;
net.cfg    = S.cfg;
end


function f = monoG_raw_w(W1,b1,W2,b2,W3,b3,q)
%#codegen
z1 = tanh(W1*q + b1);
z2 = tanh(W2*z1 + b2);
f  = W3*z2 + b3;
end


function nfl = build_nfl_v19(u)
%#codegen
% u = observer: [x; v; a; prev_I; di; T], all normalised.
% Order is exactly mr_nlcsnn/model_v19.py nfl_v19 (35 features).
x = u(1); v = u(2); a = u(3); ci = u(4); di = u(5); t = u(6);
sv = 0.1;
v_abs = abs(v);
v_pos = max(v, 0);
v_neg = min(v, 0);
sgn_v = tanh(v / sv);
slow_gate = exp(-v_abs / sv);
x_abs = abs(x);
nfl = [u; ...
       v; x*v; v*ci; v*t; ...
       tanh(2.0*v_pos); tanh(v_pos/sv); ci*tanh(v_pos/sv); ...
       v_neg*v_abs; v_neg^3; a*v_neg; ci*v_neg*v_abs; ...
       di*v; di*a; abs(di)*ci; ...
       sgn_v; ci*sgn_v; x^2; x^3; a*ci; ...
       abs(a); a*v; abs(a)*sgn_v; ci*abs(a); ...
       slow_gate; x*slow_gate; x_abs*slow_gate; ...
       ci*x*slow_gate; ci*x_abs*slow_gate; sgn_v*x_abs];
end


function h_new = gru_step_v19(net, nfl, h)
%#codegen
% PyTorch GRU, two layers, one time step. Biases are kept split exactly
% as bias_ih / bias_hh in the checkpoint export.
hh0 = h(1, :)';
r0 = sigmoid(net.W_ir0 * nfl + net.b_ir0 + net.W_hr0 * hh0 + net.b_hr0);
z0 = sigmoid(net.W_iz0 * nfl + net.b_iz0 + net.W_hz0 * hh0 + net.b_hz0);
n0 = tanh(net.W_in0 * nfl + net.b_in0 + r0 .* (net.W_hn0 * hh0 + net.b_hn0));
h0_new = (1 - z0) .* n0 + z0 .* hh0;
hh1 = h(2, :)';
r1 = sigmoid(net.W_ir1 * h0_new + net.b_ir1 + net.W_hr1 * hh1 + net.b_hr1);
z1 = sigmoid(net.W_iz1 * h0_new + net.b_iz1 + net.W_hz1 * hh1 + net.b_hz1);
n1 = tanh(net.W_in1 * h0_new + net.b_in1 + r1 .* (net.W_hn1 * hh1 + net.b_hn1));
h1_new = (1 - z1) .* n1 + z1 .* hh1;
h_new = [h0_new'; h1_new'];
end


function y = mlp3(W1, b1, W2, b2, W3, b3, x)
%#codegen
z1 = max(W1 * x + b1, 0);
z2 = max(W2 * z1 + b2, 0);
y  = W3 * z2 + b3;
end


function y = mlp2(W1, b1, W2, b2, x)
%#codegen
z1 = max(W1 * x + b1, 0);
y  = W2 * z1 + b2;
end


function G = monoG(W1, b1, W2, b2, W3, b3, f0, gref, k_skip, q)
%#codegen
% Exactly MonotonicG.forward in model_v19.py: no max(...,0) clip.
z1 = tanh(W1 * q + b1);
z2 = tanh(W2 * z1 + b2);
f  = W3 * z2 + b3;
G = ((f - f0) + k_skip * q) / gref;
end


function y = sigmoid(x)
%#codegen
y = 1 ./ (1 + exp(-x));
end


function y = softplus_stable(x)
%#codegen
y = max(x, 0) + log1p(exp(-abs(x)));
end
