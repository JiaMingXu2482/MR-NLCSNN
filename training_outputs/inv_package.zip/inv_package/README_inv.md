# 逆模型 MATLAB 包（inv_mf / inv_mf_impl_10ms）

## 先说清楚：这不是 v19 的逆模型

这是改名后的 v17 10ms 逆模型，内部正模型是 v17，不是刚换上去的
v19 A。v19 目前没有可交付的逆模型：inv_head 未训练，10ms 窗逆解
在审计里也没有全面通过的在线方案。所以闭环里是 v17 逆解去追
v19 A 这个 plant，两模型差会直接进闭环误差，这一点和正模型
刚换上去时说过的一样。

权重来源：`v17_weights.mat`（改名为 `inv_weights.mat`，内容未动），
mat 里 meta：version v17，total_epoch 330，pooled_nrmse 16.7977%，
inv_mae 0.01008 A，参数 20998。注意这是 E330 的权重，不是 v17
最终 E480（16.27%）那版。权重是 double，Simulink codegen 不会
再报之前正模型那种 single/double 类型错误。

## 包里有什么

- `inv_mf.m`：MATLAB Function 块里贴的 wrapper
- `inv_mf_impl_10ms.m`：算法实体，放在 Simulink 工作目录
- `inv_weights.mat`：v17 E330 权重与归一化参数，放在同一工作目录
- 本 README

## 替换步骤

1. 把本包三个文件（`inv_mf.m`、`inv_mf_impl_10ms.m`、`inv_weights.mat`）
   放进 Simulink 工作目录。注意：正模型包的 `fwd_weights.mat`
   是 v19 的，逆模型包的 `inv_weights.mat` 是 v17 的，两个文件
   名不同，不要互相覆盖。
2. 4 个 MATLAB Function 块里的内容换成 `inv_mf.m` 的内容。
3. 跑之前先清各角 persistent 状态：`clear inv_mf_impl_10ms`。
   正模型那边是 `clear fwd_mf_impl`，两个都要清。

## 接口

输入（全部标量）：
- `Fd_N`：期望减振器力 [N]，CarSim 符号（压缩 +）
- `t`：仿真时间 [s]，用于 dt 和限速
- `Temp_C`：油温 [degC]，如 30
- `cmpD`：减振器位移 [mm]，CarSim 符号（压缩 +）
- `cmpRD`：减振器速度 [mm/s]，CarSim 符号
- `cid`：角 id，1=L1、2=L2、3=R1、4=R2（每块固定）

输出（全部标量，力均为 CarSim 符号，可直接和 Fd 画在同一 Scope 上）：
- `I_cmd`：电流指令 [A]，限幅 [0, 1.6]，限速 160 A/s
- `Flo, Fhi`：可达力包络 [N]
- `F_clipped`：Fd 经包络限幅后的力 [N]
- `F_ach`：模型在 I_cmd 下预测的力 [N]

## 求解口径（原 v17 10ms 版，未改算法）

- 求解器每 10ms 跑一次（tick = floor(t/0.01)），tick 之间保持输出。
- 精确单步 v17 映射（完整 NFL、GRU 重步、真实 ie_buf 滞后）在
  9 点 Ie 网格上求解，最佳根按上一拍 Ie 连续性决胜，
  决胜容差 TOL_F = 15 N。
- 低速（|v| < 5 mm/s）：保持上一拍电流。
- 加速度与正模型相同：速度经 20ms 低通求导得到。
- 开环测试时 Fd 必须是 raw v17 网络力，不要喂 wrapper
  （TAU_X / 被动投影）处理过的力；闭环里 Fd 来自控制器，
  这个口径问题同样适用——Fd 的产生口径必须和逆解所逆的
  那个正模型一致。
